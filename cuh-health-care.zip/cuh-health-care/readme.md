GO to Xampp COntrol Pannel

Start the apcache and then mysql

click on the the admin next to the  mysql

In the php my admin click new and create database with name (cuh)

then create the table 
with parameters